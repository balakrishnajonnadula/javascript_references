window.addEventListener("load",onLoad);

function onLoad(){
    
    
    //data types
    /**
    
     2 types
     a) Premitive 
     b) Non premitive
    
    
    a) Premitive
    
    1. String
    2. Number
    3. Boolean
    
    b) Non premitive
    
    4. Array
    5. Object
    
    */
    
    
    
    var str = "Hyderabad";
    
    var str1 = "is a city";
    
    //concatination
    
    //document.write(str+" "+str1);
    
    
    //String Methods
    
    // 1. Substring 
    
    var para = "Share suggestions,Google ask questions and connect with other users and top contributors in the Google Chrome help Google forum. Google Google Google"
    
    //console.log(para.substr(10,50));
    
    
     // 2. indexOf 
    
   // console.log(para.indexOf("Google"));
    
     // 2. lastIndexOf 
    
    //console.log(para.lastIndexOf("Google"));
    
    //3. split
    
    //console.log(para.split("Google"));
    
    
    var from = para.indexOf("Google Chrome");
    var to = (para.indexOf("forum.") - para.indexOf("Google Chrome")) + 6;
    
    //console.log(para.substr(from,to));

    
    var str ="hyderabad+secundrabad+sr nagar+ameerpet";
    
    console.log(str.split("+").join(","));
    
}