window.addEventListener("load",onLoad);

function onLoad(){
    
    
    
    var com = new Grid();    
    com.render(document.body);
    
    
    
}