window.addEventListener("load",onLoad);

var arr = [];

var count = 0;

function onLoad(){
    
    
    createButton();
    
    
}
var boxes;
function createButton(){
    
    
    var btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Generate";
    btn.addEventListener("click",generate);
    
    document.body.appendChild(btn);
    
    var btn = document.createElement("button");
    btn.className = "btn btn1";
    btn.textContent = "Populate";
    btn.addEventListener("click",populate);
    
    document.body.appendChild(btn);
    
    
    boxes = document.createElement("div");
    document.body.appendChild(boxes);
}

function generate(){
   count++;
arr.push(count);
  console.log(count)
}

function populate(){
    
   boxes.innerHTML = "";
    
      for(var i=0;i<arr.length;i++){
      var box = document.createElement("div");
    document.body.appendChild(box);
    box.className = "box";
          box.textContent = i;
    
    boxes.appendChild(box);
          
      }
    
}
