$(window).on("load", onLoad);


var arr = ["1.jpg", "2.jpg", "3.jpg", "4.jpg"];

function onLoad() {

   
    $(".close").on("click", closePopup);

    generateImages();
}


function closePopup() {
    $(".popup").fadeOut();
}

function generateImages() {

    $.each(arr, function (key, value) {
        
        var cont = $("<div></div>");
        cont.addClass("cont");
        var image = $("<img></img>");
        image.addClass("image");
        image.attr("src","assets/" + value);
        cont.append(image);
        $(image).on("click",showImage);
        $("body").append(cont);
    })

}

function showImage(){
    $("#popup-image").attr("src",this.src);
    $(".popup").fadeIn();
    
}