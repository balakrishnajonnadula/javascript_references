//JSON : Javascript object notation
window.addEventListener("load", onLoad);

function onLoad() {
    var obj = [{
            empName: "Ramesh",
            empId: "1",
            empQualification: "B.Tech",
            designation: "Engineer"
    },
        {
            empName: "Suresh",
            empId: "2",
            empQualification: "M.Tech",
            designation: "Sr.Engineer"
    },
        {
            empName: "Naresh",
            empId: "3",
            empQualification: "M.Tech",
            designation: "Sr.Engineer"
    }
];


    for (var i = 0; i < obj.length; i++) {

        var box = document.createElement("div");
        box.className = "box";

        var left = document.createElement("div");
        left.className = "left";
        var right = document.createElement("div");
        right.className = "right";


        var name = document.createElement("h1");
        name.className = "title";
        name.textContent = obj[i].empName;

        var qualification = document.createElement("p");
        qualification.textContent = obj[i].empQualification;

        var designation = document.createElement("p");
        designation.textContent = obj[i].designation;


        var edit = document.createElement("button");
        edit.textContent = "Edit";
        edit.className = "blue";

        edit.addEventListener("click", onEdit);

        var deletes = document.createElement("button");
        deletes.textContent = "Delete";
        deletes.className = "red";


        left.appendChild(name);
        left.appendChild(qualification);
        left.appendChild(designation);

        right.appendChild(edit);
        right.appendChild(deletes);


        box.appendChild(left);
        box.appendChild(right);

        document.body.appendChild(box);


    }


}


function onEdit() {

    var title = this.parentNode.previousElementSibling.getElementsByClassName("title")[0];

    if (this.editMode) {
        this.editMode = false;
        title.contentEditable = false;
        this.textContent = "Edit";

    } else {

        this.editMode = true;
        title.contentEditable = true;
        this.textContent = "Save";
    }
}