window.addEventListener("load",onLoad);

function onLoad(){
    
    var box = document.getElementsByClassName("box")[0].style;
    
    box.width = "300px";
    box.height = "300px";
    box.border = "1px solid #e2e2e2";
    box.overflow = "auto";
    
    
    //Adding events to buttons
    
    document.getElementById("button1").addEventListener("click",getText);
    document.getElementById("button2").addEventListener("click",getText);
    document.getElementById("button3").addEventListener("click",getText);
    
}

function getText(){
    
    document.getElementsByClassName("box")[0].innerHTML =  document.getElementsByClassName("box")[0].innerHTML + '<p class="para">'+this.textContent+'<span onclick="removeText(this)">-</span></p>';
   
}

function removeText(me){
    
    document.getElementsByClassName("box")[0].removeChild(me.parentNode);

    //me.parentNode.style.display = "none";

}